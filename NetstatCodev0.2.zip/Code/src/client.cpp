#include<client.h>
#include<netstat_r.h>
#include<netstat_tcp.h>
#include<netstat_udp.h>
#include<netstat_listen.h>
#include<netstat_firefox.h>

Client :: Client()
{

}

void Client :: createSock()
{
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
		if(sockfd < 0)
		{
			cout<<"Error in connection"<<endl;
			exit(EXIT_FAILURE);
		}
}

void Client :: connectServer()
{
	memset(&server_addr, '\0', sizeof(server_addr));

	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(PORT);
	server_addr.sin_addr.s_addr = inet_addr(ADDR);


	client_fd = connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
	if(client_fd < 0){
		cout<<"Error in connection"<<endl;
		exit(EXIT_FAILURE);
	}
	cout<<"Connected to Server"<<endl;
}

void Client :: send_recv(string temp)
{
		if(sendto(sockfd, temp.c_str(), strlen(temp.c_str()),0,(struct sockaddr*)&server_addr, server_addr_len)<0)
		{
			perror("sendto() error");
			exit(EXIT_FAILURE);
		}

		if(temp=="disconnect")
		{
			close(sockfd);
			cout<<"Disconnected from server"<<endl;
			exit(EXIT_FAILURE);
		}
		else if(temp == "RT")
		{
			RoutingTable *rt;

			if(recvfrom(sockfd, &rt, sizeof(rt),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}

			rt->displayRoutingTable();
		}
		else if(temp == "TCP")
		{
			netstatTCP *tcp;
			int size;
			if(recvfrom(sockfd, &size, sizeof(size),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			cout<<size<<endl;
			tcp=new netstatTCP[size];
			if(recvfrom(sockfd, tcp, 4096 ,0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			cout<<tcp[0].getProto()<<endl;
			displayTCP_Table(tcp,size);
		}
		else if(temp == "UDP")
		{
			netstatUDP *udp;
			int size;

			if(recvfrom(sockfd, &udp, sizeof(udp),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			if(recvfrom(sockfd, &size, sizeof(size),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}


			udp->displayUDP_Table(size);
		}
		else if(temp == "Listen")
		{
			netstat_Listen *ls;
			int size;

			if(recvfrom(sockfd, &ls, sizeof(ls),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			if(recvfrom(sockfd, &size, sizeof(size),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}


			ls->displayListen(size);
		}
		else if(temp == "firefox")
		{
			netstatFIREFOX *nf;
			int size;

			if(recvfrom(sockfd, &nf, sizeof(nf),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			if(recvfrom(sockfd, &size, sizeof(size),0,(struct sockaddr*)&client_addr, (socklen_t*)&client_addr_len)<0)
			{
				perror("sendto() error");
				exit(EXIT_FAILURE);
			}
			if(size==0)
			{
				cout<<"No such Application Running"<<endl;
			}
			else
			{
				nf->displayFIREFOX_Table(size);
			}	
		}
		else{}
	
}

void Client :: closeSock()
{
	close(sockfd);
}

Client :: ~Client()
{

}