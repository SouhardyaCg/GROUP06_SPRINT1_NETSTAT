#include<netstat_udp.h>

void getUDP_Table()
{
	if(fork()==0)
	{
	
		int file=open("udpFile.txt",O_WRONLY | O_CREAT ,0777);
		dup2(file,STDOUT_FILENO);
		close(file);
		char* cmd="netstat";
		char *args[]={"netstat","-uan",NULL};	
		execvp(cmd,args);
		exit(EXIT_SUCCESS);
	}
	
}

void storeUDP_Table(list<string> &dataList)
{
	fstream fs;
	fs.open("udpFile.txt",ios::in|ios::out);
	if(!fs)
	{
		cout<<"No such File"<<endl;
	}
	else
	{
		int count =0;
		string line;
		while(getline(fs,line))
		{
			count++;
			if(count>2)
				dataList.push_back(line);
			else
				continue;
		}
	}
	fs.close();
}
netstatUDP* UDPdriver()
{
	list<string> myData;
	char data[6][20];

		getUDP_Table();
		storeUDP_Table(myData);
	
		int size=myData.size();
		int i=0;
		netstatUDP* udp=new netstatUDP[size];

		for(auto it=myData.begin();it!=myData.end();it++)
		{
			string str=*it;
			stringstream st(str);
			string temp;
			int j=0;
			while(st)
			{
				st>>temp;
				if(st)
				{
					strcpy(data[j],temp.c_str());
					j++;
				}
			}
			udp[i].setProto(data);
			udp[i].setRecv(data);
			udp[i].setSend(data);
			udp[i].setLocal_Address(data);
			udp[i].setForeign_Address(data);
			udp[i].setState(data);

			i++;
		}

		return udp;
}

int returnUDPSize()
{
	int size=0;
	fstream fs;
	fs.open("udpFile.txt",ios::in|ios::out);
	if(!fs)
	{
		cout<<"No such File"<<endl;
	}
	else
	{
		int count =0;
		string line;
		while(getline(fs,line))
		{
			count++;
			if(count>2)
				size++;
			else
				continue;
		}
	}
	fs.close();
	return size;
}

netstatUDP :: netstatUDP()
{}

void netstatUDP :: setProto(char data[][20])
{
	Proto=data[0];	
}
string netstatUDP :: getProto()
{
	return Proto;
}
void netstatUDP :: setRecv(char data[][20])
{
	Recv=data[1];
}
string netstatUDP :: getRecv()
{
	return Recv;
}
void netstatUDP :: setSend(char data[][20])
{
	Send=data[2];
}
string netstatUDP :: getSend()
{
	return Send;
}
void netstatUDP :: setLocal_Address(char data[][20])
{
	Local_Address=data[3];
}
string netstatUDP :: getLocal_Address()
{
	return Local_Address;
}
void netstatUDP :: setForeign_Address(char data[][20])
{
	Foreign_Address=data[4];
}
string netstatUDP :: getForeign_Address()
{
	return Foreign_Address;
}
void netstatUDP :: setState(char data[][20])
{
	State=data[5];
}
string netstatUDP :: getState()
{
	return State;
}

void netstatUDP :: displayUDP_Table(int size)
{
	netstatUDP* udp;
	udp = UDPdriver();

	for(int i=0;i<size;i++)
	{
		cout<<"-------------- Kernel UDP Table Dataset "<<i+1<<" ------------------"<<endl;
		cout<<"Proto : "<<udp[i].Proto<<endl;
		cout<<"Recv-Q :"<<udp[i].Recv<<endl;
		cout<<"Send-Q :"<<udp[i].Send<<endl;
		cout<<"Local Address :"<<udp[i].Local_Address<<endl;
		cout<<"Foreign Address :"<<udp[i].Foreign_Address<<endl;
		cout<<"State :"<<udp[i].State<<endl;
		cout<<"-----------------------------------------------------"<<endl;
	}

}

netstatUDP::~netstatUDP()
{}
